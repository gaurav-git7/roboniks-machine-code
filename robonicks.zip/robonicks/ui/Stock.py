# In your Stock.py file

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import json

class IVDStockPage(tk.Frame):
    def __init__(self, root, go_back_callback=None):
        super().__init__(root)
        self.root = root
        self.go_back_callback = go_back_callback
        self.configure(bg='#F7F9FC')  # Light background
        
        # Color scheme that matches your app
        self.COLORS = {
            'primary': '#1BC6B4',      # Teal
            'secondary': '#3AC7F1',    # Light Blue
            'accent': '#2E8B57',       # Sea Green
            'danger': '#E74C3C',       # Soft Red
            'warning': '#F39C12',      # Orange
            'success': '#27AE60',      # Green
            'light': '#F7F9FC',        # Light Gray
            'white': '#FFFFFF',
            'dark': '#2C3E50',         # Dark Gray
            'gray': '#95A5A6'          # Medium Gray
        }
        
        # Track batch information
        self.batches = {}  # {batch_id: {tests_per_pack: int, total_tests: int}}
        
        self.create_widgets()
        self.load_sample_data()
        self.pack(fill='both', expand=True)
        
    def create_widgets(self):
        # Main container with subtle shadow effect
        main_container = tk.Frame(self, bg=self.COLORS['light'])
        main_container.pack(fill='both', expand=True, padx=2, pady=2)
        
        # Header Section
        header = tk.Frame(main_container, bg=self.COLORS['primary'], height=80)
        header.pack(fill=tk.X, pady=(0, 20))
        
        # Title with better typography
        title_frame = tk.Frame(header, bg=self.COLORS['primary'])
        title_frame.pack(side=tk.LEFT, padx=30)
        
        title_label = tk.Label(
            title_frame, 
            text="I.V.D",
            font=("Montserrat", 32, "bold"),
            fg=self.COLORS['white'], 
            bg=self.COLORS['primary']
        )
        title_label.pack(anchor='w')
        
        subtitle_label = tk.Label(
            title_frame,
            text="Stock Management",
            font=("Montserrat", 14),
            fg=self.COLORS['white'],
            bg=self.COLORS['primary']
        )
        subtitle_label.pack(anchor='w')
        
        # Right side header content
        header_right = tk.Frame(header, bg=self.COLORS['primary'])
        header_right.pack(side=tk.RIGHT, padx=30)
        
        # Date display
        date_str = datetime.now().strftime('%B %d, %Y')
        date_label = tk.Label(
            header_right,
            text=date_str,
            font=("Montserrat", 12),
            fg=self.COLORS['white'],
            bg=self.COLORS['primary']
        )
        date_label.pack(anchor='e')
        
        # Back Button with better styling
        if self.go_back_callback:
            back_btn = tk.Button(
                header_right,
                text="← Back to Menu",
                font=("Montserrat", 11, "bold"),
                bg=self.COLORS['secondary'],
                fg=self.COLORS['white'],
                activebackground=self.COLORS['accent'],
                activeforeground=self.COLORS['white'],
                bd=0,
                relief=tk.FLAT,
                padx=20,
                pady=8,
                cursor='hand2',
                command=self.go_back
            )
            back_btn.pack(anchor='e', pady=(10, 0))
        
        # Main content container with card-like appearance
        content_card = tk.Frame(
            main_container, 
            bg=self.COLORS['white'],
            relief=tk.RAISED,
            bd=1
        )
        content_card.pack(fill='both', expand=True, padx=20, pady=(0, 20))
        
        # Add Stock Section
        add_stock_section = tk.Frame(content_card, bg=self.COLORS['white'])
        add_stock_section.pack(fill='x', padx=30, pady=(20, 10))
        
        add_stock_label = tk.Label(
            add_stock_section,
            text="Add New Stock",
            font=('Montserrat', 16, 'bold'),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        add_stock_label.pack(side='left', padx=(0, 20))
        
        # Batch ID Entry
        batch_frame = tk.Frame(add_stock_section, bg=self.COLORS['white'])
        batch_frame.pack(side='left', padx=10)
        
        batch_label = tk.Label(
            batch_frame,
            text="Batch ID:",
            font=('Montserrat', 11),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        batch_label.pack(side='left', padx=(0, 5))
        
        self.batch_id_var = tk.StringVar()
        batch_entry = tk.Entry(
            batch_frame,
            textvariable=self.batch_id_var,
            font=('Montserrat', 11),
            width=15,
            relief=tk.SOLID,
            bd=1,
            bg=self.COLORS['light'],
            fg=self.COLORS['dark']
        )
        batch_entry.pack(side='left', padx=(0, 10))
        
        # Tests per pack entry
        tests_frame = tk.Frame(add_stock_section, bg=self.COLORS['white'])
        tests_frame.pack(side='left', padx=10)
        
        tests_label = tk.Label(
            tests_frame,
            text="Tests per pack:",
            font=('Montserrat', 11),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        tests_label.pack(side='left', padx=(0, 5))
        
        self.tests_per_pack_var = tk.StringVar(value="100")
        tests_entry = tk.Entry(
            tests_frame,
            textvariable=self.tests_per_pack_var,
            font=('Montserrat', 11),
            width=8,
            relief=tk.SOLID,
            bd=1,
            bg=self.COLORS['light'],
            fg=self.COLORS['dark'],
            justify='center'
        )
        tests_entry.pack(side='left', padx=(0, 10))
        
        # Number of packs entry
        packs_frame = tk.Frame(add_stock_section, bg=self.COLORS['white'])
        packs_frame.pack(side='left', padx=10)
        
        packs_label = tk.Label(
            packs_frame,
            text="Number of packs:",
            font=('Montserrat', 11),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        packs_label.pack(side='left', padx=(0, 5))
        
        self.num_packs_var = tk.StringVar(value="1")
        packs_entry = tk.Entry(
            packs_frame,
            textvariable=self.num_packs_var,
            font=('Montserrat', 11),
            width=8,
            relief=tk.SOLID,
            bd=1,
            bg=self.COLORS['light'],
            fg=self.COLORS['dark'],
            justify='center'
        )
        packs_entry.pack(side='left', padx=(0, 10))
        
        # Add Stock Button
        add_btn = tk.Button(
            add_stock_section,
            text="➕ Add Stock",
            command=self.add_stock,
            font=('Montserrat', 11, 'bold'),
            bg=self.COLORS['success'],
            fg=self.COLORS['white'],
            activebackground=self.COLORS['accent'],
            activeforeground=self.COLORS['white'],
            padx=20,
            pady=8,
            relief=tk.FLAT,
            cursor='hand2'
        )
        add_btn.pack(side='left', padx=(20, 0))
        add_btn.bind('<Enter>', lambda e: self.on_button_hover(add_btn, self.COLORS['success'], True))
        add_btn.bind('<Leave>', lambda e: self.on_button_hover(add_btn, self.COLORS['success'], False))
        
        # Stock Details Section
        details_header = tk.Frame(content_card, bg=self.COLORS['white'], height=60)
        details_header.pack(fill='x', padx=30, pady=(20, 10))
        
        details_label = tk.Label(
            details_header,
            text="Stock Details",
            font=('Montserrat', 18, 'bold'),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        details_label.pack(side='left')
        
        # Create Table with batch column
        self.create_table(content_card)
        
        # Average Consumption Section
        avg_section = tk.Frame(content_card, bg=self.COLORS['white'])
        avg_section.pack(fill='x', padx=30, pady=20)
        
        avg_label = tk.Label(
            avg_section,
            text="Average consumption per month:",
            font=('Montserrat', 13),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        avg_label.pack(side='left')
        
        # Styled Entry with placeholder
        entry_frame = tk.Frame(avg_section, bg=self.COLORS['white'])
        entry_frame.pack(side='left', padx=15)
        
        self.avg_var = tk.StringVar()
        self.avg_entry = tk.Entry(
            entry_frame,
            textvariable=self.avg_var,
            font=('Montserrat', 12),
            width=18,
            justify='center',
            relief=tk.SOLID,
            bd=1,
            bg=self.COLORS['light'],
            fg=self.COLORS['dark'],
            insertbackground=self.COLORS['primary']
        )
        self.avg_entry.pack()
        
        # Add hint/unit label
        unit_label = tk.Label(
            avg_section,
            text="tests/month",
            font=('Montserrat', 10),
            bg=self.COLORS['white'],
            fg=self.COLORS['gray']
        )
        unit_label.pack(side='left', padx=5)
        
        # Buttons Section with improved layout
        button_section = tk.Frame(content_card, bg=self.COLORS['white'])
        button_section.pack(fill='x', padx=30, pady=(0, 30))
        
        # Action buttons frame
        action_buttons = tk.Frame(button_section, bg=self.COLORS['white'])
        action_buttons.pack(side='left')
        
        # Button definitions with consistent styling
        button_definitions = [
            ("💾 Save Data", self.COLORS['success'], self.save_data),
            ("📂 Load Data", self.COLORS['secondary'], self.load_data),
            ("🧮 Calculate Totals", self.COLORS['warning'], self.calculate_totals),
            ("🗑️ Clear All", self.COLORS['danger'], self.clear_data),
            ("📦 View Batches", self.COLORS['accent'], self.view_batches)
        ]
        
        for text, color, command in button_definitions:
            btn = tk.Button(
                action_buttons,
                text=text,
                command=command,
                font=('Montserrat', 11, 'bold'),
                bg=color,
                fg=self.COLORS['white'],
                activebackground=color,
                activeforeground=self.COLORS['white'],
                padx=20,
                pady=10,
                relief=tk.FLAT,
                cursor='hand2',
                bd=0
            )
            btn.pack(side='left', padx=5)
            # Bind hover effects
            btn.bind('<Enter>', lambda e, b=btn, c=color: 
                    self.on_button_hover(b, c, True))
            btn.bind('<Leave>', lambda e, b=btn, c=color: 
                    self.on_button_hover(b, c, False))
        
        # Summary frame on right side
        summary_frame = tk.Frame(button_section, bg=self.COLORS['white'])
        summary_frame.pack(side='right')
        
        # Total items summary
        self.total_items_var = tk.StringVar(value="Total Tests: 0")
        total_label = tk.Label(
            summary_frame,
            textvariable=self.total_items_var,
            font=('Montserrat', 11),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        total_label.pack(anchor='e')
        
        # Total batches summary
        self.total_batches_var = tk.StringVar(value="Total Batches: 0")
        batches_label = tk.Label(
            summary_frame,
            textvariable=self.total_batches_var,
            font=('Montserrat', 11),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        batches_label.pack(anchor='e')
        
        # Update summary
        self.update_summary()
        
    def create_table(self, parent):
        # Create frame for treeview with subtle border
        table_frame = tk.Frame(
            parent, 
            bg=self.COLORS['light'],
            relief=tk.SOLID,
            bd=1
        )
        table_frame.pack(fill='both', expand=True, padx=30, pady=(0, 20))
        
        # Create custom style for treeview
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure Treeview style
        style.configure(
            "Custom.Treeview",
            background=self.COLORS['white'],
            foreground=self.COLORS['dark'],
            rowheight=40,
            fieldbackground=self.COLORS['white'],
            bordercolor=self.COLORS['light'],
            borderwidth=1,
            font=('Montserrat', 11)
        )
        
        style.configure(
            "Custom.Treeview.Heading",
            font=('Montserrat', 12, 'bold'),
            background=self.COLORS['primary'],
            foreground=self.COLORS['white'],
            relief='flat',
            borderwidth=0
        )
        
        style.map(
            "Custom.Treeview.Heading",
            background=[('active', self.COLORS['secondary'])]
        )
        
        # Configure row colors
        style.map(
            "Custom.Treeview",
            background=[('selected', self.COLORS['secondary'] + '80')],
            foreground=[('selected', self.COLORS['white'])]
        )
        
        # Add batch column
        columns = ('sr_no', 'batch_id', 'unopened', 'opened', 'total')
        self.tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show='headings',
            height=7,
            selectmode='extended',
            style="Custom.Treeview"
        )
        
        # Define headings with center alignment
        headings = [
            ('Sr No.', 80),
            ('Batch ID', 120),
            ('Unopened packs', 150),
            ('Opened tests', 150),
            ('Total tests', 120)
        ]
        
        for i, (text, width) in enumerate(headings):
            self.tree.heading(columns[i], text=text, anchor='center')
            self.tree.column(columns[i], width=width, anchor='center', minwidth=width)
        
        # Tag configuration for alternating row colors
        self.tree.tag_configure('oddrow', background=self.COLORS['light'])
        self.tree.tag_configure('evenrow', background=self.COLORS['white'])
        
        # Add scrollbars
        v_scrollbar = ttk.Scrollbar(
            table_frame, 
            orient='vertical', 
            command=self.tree.yview
        )
        h_scrollbar = ttk.Scrollbar(
            table_frame, 
            orient='horizontal', 
            command=self.tree.xview
        )
        self.tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Grid layout for table and scrollbars
        self.tree.grid(row=0, column=0, sticky='nsew', padx=1, pady=1)
        v_scrollbar.grid(row=0, column=1, sticky='ns')
        h_scrollbar.grid(row=1, column=0, sticky='ew')
        
        # Configure grid weights
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        
        # Bind events
        self.tree.bind('<Double-1>', self.on_double_click)
        self.tree.bind('<KeyRelease>', self.on_table_change)
        
        # Store entry widgets for editing
        self.entry_widgets = {}
        
    def add_stock(self):
        """Add new stock with batch ID"""
        batch_id = self.batch_id_var.get().strip()
        if not batch_id:
            messagebox.showwarning("Warning", "Please enter a Batch ID", parent=self)
            return
        
        if batch_id in self.batches:
            response = messagebox.askyesno(
                "Batch Exists",
                f"Batch ID '{batch_id}' already exists. Do you want to add more stock to this batch?",
                parent=self
            )
            if not response:
                return
        
        try:
            tests_per_pack = int(self.tests_per_pack_var.get())
            num_packs = int(self.num_packs_var.get())
            
            if tests_per_pack <= 0 or num_packs <= 0:
                raise ValueError("Values must be positive")
                
        except ValueError:
            messagebox.showerror(
                "Invalid Input",
                "Please enter valid positive numbers for tests per pack and number of packs",
                parent=self
            )
            return
        
        # Calculate totals
        total_tests = tests_per_pack * num_packs
        
        if batch_id in self.batches:
            # Update existing batch
            self.batches[batch_id]['tests_per_pack'] = tests_per_pack
            self.batches[batch_id]['total_tests'] += total_tests
            
            # Update tree item
            for item in self.tree.get_children():
                values = self.tree.item(item, 'values')
                if values[1] == batch_id:
                    current_unopened = int(values[2]) if values[2] else 0
                    current_opened = int(values[3]) if values[3] else 0
                    current_total = int(values[4]) if values[4] else 0
                    
                    new_unopened = current_unopened + num_packs
                    new_total = current_total + total_tests
                    
                    self.tree.item(item, values=(
                        values[0],
                        batch_id,
                        str(new_unopened),
                        str(current_opened),
                        str(new_total)
                    ))
                    break
        else:
            # Add new batch
            self.batches[batch_id] = {
                'tests_per_pack': tests_per_pack,
                'total_tests': total_tests
            }
            
            # Add to tree
            next_sr_no = len(self.tree.get_children()) + 1
            tag = 'evenrow' if next_sr_no % 2 == 0 else 'oddrow'
            
            self.tree.insert('', 'end', values=(
                str(next_sr_no),
                batch_id,
                str(num_packs),  # Unopened packs
                "0",            # Opened tests
                str(total_tests)  # Total tests
            ), tags=(tag,))
        
        # Clear input fields
        self.batch_id_var.set("")
        self.num_packs_var.set("1")
        
        # Update summaries
        self.update_summary()
        messagebox.showinfo(
            "Success",
            f"Added {num_packs} pack(s) of {tests_per_pack} tests each\n"
            f"Batch: {batch_id}\n"
            f"Total tests added: {total_tests}",
            parent=self
        )
    
    def view_batches(self):
        """Show batch summary window"""
        if not self.batches:
            messagebox.showinfo("No Batches", "No batches have been added yet.", parent=self)
            return
        
        batch_window = tk.Toplevel(self)
        batch_window.title("Batch Summary")
        batch_window.geometry("500x400")
        batch_window.configure(bg=self.COLORS['light'])
        batch_window.transient(self)
        batch_window.grab_set()
        
        # Center window
        batch_window.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() // 2) - (500 // 2)
        y = self.winfo_y() + (self.winfo_height() // 2) - (400 // 2)
        batch_window.geometry(f"+{x}+{y}")
        
        # Header
        header = tk.Frame(batch_window, bg=self.COLORS['primary'], height=60)
        header.pack(fill='x')
        
        header_label = tk.Label(
            header,
            text="Batch Summary",
            font=('Montserrat', 18, 'bold'),
            fg=self.COLORS['white'],
            bg=self.COLORS['primary']
        )
        header_label.pack(pady=15)
        
        # Batch list in a treeview
        tree_frame = tk.Frame(batch_window, bg=self.COLORS['light'])
        tree_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Create treeview for batches
        batch_tree = ttk.Treeview(
            tree_frame,
            columns=('batch_id', 'tests_per_pack', 'total_tests'),
            show='headings',
            height=10
        )
        
        # Configure style
        style = ttk.Style()
        style.configure("Batch.Treeview", font=('Montserrat', 11))
        style.configure("Batch.Treeview.Heading", font=('Montserrat', 12, 'bold'))
        
        # Define headings
        batch_tree.heading('batch_id', text='Batch ID')
        batch_tree.heading('tests_per_pack', text='Tests per Pack')
        batch_tree.heading('total_tests', text='Total Tests')
        
        batch_tree.column('batch_id', width=150)
        batch_tree.column('tests_per_pack', width=120, anchor='center')
        batch_tree.column('total_tests', width=120, anchor='center')
        
        # Add batches to tree
        total_all_tests = 0
        for batch_id, batch_info in self.batches.items():
            batch_tree.insert('', 'end', values=(
                batch_id,
                batch_info['tests_per_pack'],
                batch_info['total_tests']
            ))
            total_all_tests += batch_info['total_tests']
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(tree_frame, orient='vertical', command=batch_tree.yview)
        batch_tree.configure(yscrollcommand=scrollbar.set)
        
        batch_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # Footer with totals
        footer = tk.Frame(batch_window, bg=self.COLORS['white'])
        footer.pack(fill='x', padx=20, pady=10)
        
        total_batches_label = tk.Label(
            footer,
            text=f"Total Batches: {len(self.batches)}",
            font=('Montserrat', 12, 'bold'),
            bg=self.COLORS['white'],
            fg=self.COLORS['dark']
        )
        total_batches_label.pack(side='left', padx=10)
        
        total_tests_label = tk.Label(
            footer,
            text=f"Total Tests: {total_all_tests}",
            font=('Montserrat', 12, 'bold'),
            bg=self.COLORS['white'],
            fg=self.COLORS['success']
        )
        total_tests_label.pack(side='right', padx=10)
    
    def on_button_hover(self, button, color, hover):
        """Handle button hover effects"""
        if hover:
            r, g, b = self.hex_to_rgb(color)
            r = max(0, r - 20)
            g = max(0, g - 20)
            b = max(0, b - 20)
            hover_color = f'#{r:02x}{g:02x}{b:02x}'
            button.config(bg=hover_color)
        else:
            button.config(bg=color)
    
    def hex_to_rgb(self, hex_color):
        """Convert hex color to RGB tuple"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def on_double_click(self, event):
        """Handle double-click for editing cells"""
        region = self.tree.identify_region(event.x, event.y)
        if region == "cell":
            item = self.tree.identify_row(event.y)
            column = self.tree.identify_column(event.x)
            col_index = int(column.replace('#', '')) - 1
            
            # Skip Sr No and Batch ID columns (not editable)
            if col_index in [0, 1]:
                return
                
            values = self.tree.item(item, 'values')
            current_value = values[col_index] if col_index < len(values) else ''
            
            x, y, width, height = self.tree.bbox(item, column)
            
            # Create entry widget for editing
            entry = tk.Entry(
                self.tree, 
                font=('Montserrat', 11),
                bg=self.COLORS['white'],
                fg=self.COLORS['dark'],
                relief=tk.SOLID,
                bd=1,
                justify='center'
            )
            entry.place(x=x, y=y, width=width, height=height)
            entry.insert(0, current_value)
            entry.select_range(0, tk.END)
            entry.focus()
            
            self.entry_widgets[item] = (entry, item, col_index)
            
            # Bind events
            entry.bind('<Return>', lambda e, i=item: self.save_edit(i))
            entry.bind('<FocusOut>', lambda e, i=item: self.save_edit(i))
            entry.bind('<Escape>', lambda e, i=item: self.cancel_edit(i))
    
    def save_edit(self, item):
        """Save edited cell value"""
        if item in self.entry_widgets:
            entry, item, col_index = self.entry_widgets[item]
            new_value = entry.get()
            
            values = list(self.tree.item(item, 'values'))
            values[col_index] = new_value
            
            # If editing unopened or opened, update batch info
            batch_id = values[1]
            if batch_id and batch_id in self.batches and col_index in [2, 3]:
                try:
                    unopened = int(values[2]) if values[2] else 0
                    opened = int(values[3]) if values[3] else 0
                    
                    # Calculate total tests
                    tests_per_pack = self.batches[batch_id]['tests_per_pack']
                    total_tests = (unopened * tests_per_pack) + opened
                    
                    values[4] = str(total_tests)
                    self.batches[batch_id]['total_tests'] = total_tests
                    
                except ValueError:
                    values[4] = "0"
            
            self.tree.item(item, values=values)
            
            entry.destroy()
            del self.entry_widgets[item]
            
            self.update_summary()
    
    def cancel_edit(self, item):
        """Cancel editing"""
        if item in self.entry_widgets:
            entry, _, _ = self.entry_widgets[item]
            entry.destroy()
            del self.entry_widgets[item]
    
    def on_table_change(self, event):
        """Handle table changes"""
        self.update_summary()
    
    def calculate_row_total(self, item):
        """Calculate total for a specific row"""
        values = list(self.tree.item(item, 'values'))
        batch_id = values[1]
        
        if batch_id and batch_id in self.batches:
            try:
                unopened = int(values[2]) if values[2] else 0
                opened = int(values[3]) if values[3] else 0
                tests_per_pack = self.batches[batch_id]['tests_per_pack']
                total = (unopened * tests_per_pack) + opened
                values[4] = str(total)
                self.batches[batch_id]['total_tests'] = total
            except:
                values[4] = '0'
        else:
            try:
                unopened = int(values[2]) if values[2] else 0
                opened = int(values[3]) if values[3] else 0
                values[4] = str(unopened + opened)  # Default: 1 test per pack
            except:
                values[4] = '0'
            
        self.tree.item(item, values=values)
    
    def update_summary(self):
        """Update summary information"""
        total_tests = 0
        
        for item in self.tree.get_children():
            values = self.tree.item(item, 'values')
            total = values[4] if values[4] != '' else '0'
            total_tests += int(total)
        
        self.total_items_var.set(f"Total Tests: {total_tests}")
        self.total_batches_var.set(f"Total Batches: {len(self.batches)}")
    
    def calculate_totals(self):
        """Calculate totals for all rows"""
        for item in self.tree.get_children():
            self.calculate_row_total(item)
        self.update_summary()
        messagebox.showinfo(
            "Success", 
            "All totals calculated!", 
            parent=self
        )
    
    def clear_data(self):
        """Clear all data from the table"""
        if messagebox.askyesno(
            "Confirm Clear",
            "Are you sure you want to clear all data?",
            parent=self
        ):
            for item in self.tree.get_children():
                self.tree.delete(item)
            
            self.batches.clear()
            self.avg_var.set("")
            
            self.update_summary()
            messagebox.showinfo(
                "Cleared", 
                "All data has been cleared.", 
                parent=self
            )
    
    def save_data(self):
        """Save current stock data to file with batch info"""
        data = {
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "items": [],
            "batches": self.batches,
            "average_consumption": self.avg_var.get()
        }
        
        for item in self.tree.get_children():
            values = self.tree.item(item, 'values')
            item_data = {
                "sr_no": values[0],
                "batch_id": values[1],
                "unopened_packs": values[2] or "0",
                "opened_tests": values[3] or "0",
                "total_tests": values[4] or "0"
            }
            data["items"].append(item_data)
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[
                ("JSON Files", "*.json"),
                ("CSV Files", "*.csv"),
                ("All Files", "*.*")
            ],
            title="Save Stock Data",
            initialfile=f"stock_data_{datetime.now().strftime('%Y%m%d')}"
        )
        
        if filename:
            try:
                with open(filename, 'w') as f:
                    json.dump(data, f, indent=4)
                messagebox.showinfo(
                    "Success", 
                    f"Data saved successfully to:\n{filename}",
                    parent=self
                )
            except Exception as e:
                messagebox.showerror(
                    "Error", 
                    f"Failed to save data: {str(e)}",
                    parent=self
                )
    
    def load_data(self):
        """Load stock data from file with batch info"""
        filename = filedialog.askopenfilename(
            filetypes=[
                ("JSON Files", "*.json"),
                ("CSV Files", "*.csv"),
                ("All Files", "*.*")
            ],
            title="Load Stock Data"
        )
        
        if filename:
            try:
                with open(filename, 'r') as f:
                    data = json.load(f)
                
                # Clear existing data
                for item in self.tree.get_children():
                    self.tree.delete(item)
                
                # Load batches
                self.batches = data.get("batches", {})
                
                # Load items
                for i, item_data in enumerate(data.get("items", [])):
                    tag = 'evenrow' if (i + 1) % 2 == 0 else 'oddrow'
                    values = (
                        item_data.get("sr_no", str(i + 1)),
                        item_data.get("batch_id", ""),
                        item_data.get("unopened_packs", ""),
                        item_data.get("opened_tests", ""),
                        item_data.get("total_tests", "")
                    )
                    self.tree.insert('', 'end', values=values, tags=(tag,))
                
                # Load average consumption
                self.avg_var.set(data.get("average_consumption", ""))
                
                self.update_summary()
                messagebox.showinfo(
                    "Success", 
                    f"Data loaded successfully from:\n{filename}",
                    parent=self
                )
                
            except Exception as e:
                messagebox.showerror(
                    "Error", 
                    f"Failed to load data: {str(e)}",
                    parent=self
                )
    
    def load_sample_data(self):
        """Load sample data for testing"""
        sample_batches = {
            "BATCH001": {"tests_per_pack": 100, "total_tests": 7500},
            "BATCH002": {"tests_per_pack": 100, "total_tests": 4500},
            "BATCH003": {"tests_per_pack": 100, "total_tests": 6000}
        }
        
        sample_data = [
            (1, "BATCH001", "50", "25", "7525"),
            (2, "BATCH002", "30", "15", "4515"),
            (3, "BATCH003", "40", "20", "6020")
        ]
        
        self.batches = sample_batches
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, data in enumerate(sample_data):
            tag = 'evenrow' if (i + 1) % 2 == 0 else 'oddrow'
            self.tree.insert('', 'end', values=data, tags=(tag,))
        
        self.avg_var.set("1200")
        self.update_summary()
    
    def go_back(self):
        """Go back to home menu"""
        self.destroy()
        if self.go_back_callback:
            self.go_back_callback()