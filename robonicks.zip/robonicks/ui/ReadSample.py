import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

class ReadSamplePage(tk.Frame):
    def __init__(self, root, go_back_callback=None):
        super().__init__(root)
        self.root = root
        self.go_back_callback = go_back_callback
          
        # Color scheme   
        self.COLORS = {
            'primary': '#1BC6B4',      # Teal
            'secondary': '#3AC7F1',    # Light Blue
            'accent': '#2E8B57',       # Sea Green
            'danger': '#E74C3C',       # Red
            'warning': '#F39C12',      # Orange
            'success': '#27AE60',      # Green
            'light': '#F7F9FC',        # Light Gray
            'white': '#FFFFFF',
            'dark': '#2C3E50',         # Dark Gray
            'gray': '#95A5A6'          # Medium Gray
        }
        
        self.build_ui()
        self.pack(fill='both', expand=True)
    
    def build_ui(self):
        # Main container
        main_container = tk.Frame(self, bg=self.COLORS['light'])
        main_container.pack(fill='both', expand=True)
        
        # Header
        header = tk.Frame(main_container, bg=self.COLORS['primary'], height=80)
        header.pack(fill='x', pady=(0, 20))
        
        # Title
        title_frame = tk.Frame(header, bg=self.COLORS['primary'])
        title_frame.pack(side='left', padx=30, fill='y')
        
        tk.Label(
            title_frame,
            text="🔬 I.V.D",
            font=("Montserrat", 28, "bold"),
            fg="white",
            bg=self.COLORS['primary']
        ).pack(anchor='w')
        
        tk.Label(
            title_frame,
            text="Parasite Diagnostic System",
            font=("Montserrat", 12),
            fg="#E8F4F8",
            bg=self.COLORS['primary']
        ).pack(anchor='w', pady=(5, 0))
        
        # Back button
        if self.go_back_callback:
            back_btn = tk.Button(
                header,
                text="← Back to Home",
                font=("Montserrat", 11, "bold"),
                bg=self.COLORS['secondary'],
                fg="white",
                activebackground=self.COLORS['accent'],
                bd=0,
                relief=tk.FLAT,
                padx=20,
                pady=8,
                cursor="hand2",
                command=self.go_back
            )
            back_btn.pack(side='right', padx=30)
        
        # Main content area
        content = tk.Frame(main_container, bg=self.COLORS['light'])
        content.pack(fill='both', expand=True, padx=20, pady=(0, 20))
        
        # Left panel - Sample Input
        left_panel = tk.Frame(content, bg='white', relief=tk.RAISED, bd=2)
        left_panel.pack(side='left', fill='both', expand=True, padx=(0, 10))
        
        # Left panel header
        left_header = tk.Frame(left_panel, bg=self.COLORS['primary'], height=40)
        left_header.pack(fill='x')
        
        tk.Label(
            left_header,
            text="Sample Processing",
            font=("Montserrat", 14, "bold"),
            fg="white",
            bg=self.COLORS['primary']
        ).pack(side='left', padx=15)
        
        # ID section
        id_frame = tk.Frame(left_panel, bg='white', padx=20, pady=20)
        id_frame.pack(fill='x', pady=(10, 0))
        
        tk.Label(
            id_frame,
            text="ID:",
            font=("Montserrat", 12, "bold"),
            bg='white',
            fg=self.COLORS['dark']
        ).pack(anchor='w')
        
        # ID input options
        id_options_frame = tk.Frame(id_frame, bg='white')
        id_options_frame.pack(fill='x', pady=(10, 0))
        
        # Barcode/auto selection
        self.id_method = tk.StringVar(value="auto")
        
        barcode_radio = tk.Radiobutton(
            id_options_frame,
            text="Barcode",
            variable=self.id_method,
            value="barcode",
            bg='white',
            font=("Montserrat", 10)
        )
        barcode_radio.pack(side='left', padx=(0, 20))
        
        auto_radio = tk.Radiobutton(
            id_options_frame,
            text="Auto-generate",
            variable=self.id_method,
            value="auto",
            bg='white',
            font=("Montserrat", 10)
        )
        auto_radio.pack(side='left')
        
        # ID input field
        id_input_frame = tk.Frame(id_frame, bg='white')
        id_input_frame.pack(fill='x', pady=(10, 0))
        
        self.id_var = tk.StringVar()
        id_entry = tk.Entry(
            id_input_frame,
            textvariable=self.id_var,
            font=("Montserrat", 11),
            width=30,
            relief=tk.SOLID,
            bd=1
        )
        id_entry.pack(side='left', padx=(0, 10))
        
        # Generate button
        gen_btn = tk.Button(
            id_input_frame,
            text="Generate ID",
            command=self.generate_id,
            bg=self.COLORS['secondary'],
            fg="white",
            font=("Montserrat", 10),
            padx=15,
            pady=5
        )
        gen_btn.pack(side='left')
        
        # Current date
        date_frame = tk.Frame(id_frame, bg='white')
        date_frame.pack(fill='x', pady=(20, 0))
        
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        tk.Label(
            date_frame,
            text="Current Date:",
            font=("Montserrat", 11, "bold"),
            bg='white',
            fg=self.COLORS['dark']
        ).pack(side='left', padx=(0, 10))
        
        date_label = tk.Label(
            date_frame,
            textvariable=self.date_var,
            font=("Montserrat", 11),
            bg='white',
            fg=self.COLORS['dark']
        )
        date_label.pack(side='left')
        
        # Cuvette instructions
        instructions_frame = tk.Frame(left_panel, bg='white', padx=20, pady=20)
        instructions_frame.pack(fill='x', pady=(10, 0))
        
        # Step 1
        step1_frame = tk.Frame(instructions_frame, bg='white')
        step1_frame.pack(fill='x', pady=(0, 15))
        
        tk.Label(
            step1_frame,
            text="1. Remove cuvette if present & press Enter",
            font=("Montserrat", 11),
            bg='white',
            fg=self.COLORS['dark']
        ).pack(side='left', padx=(0, 15))
        
        step1_btn = tk.Button(
            step1_frame,
            text="Enter",
            command=self.remove_cuvette,
            bg=self.COLORS['warning'],
            fg="white",
            font=("Montserrat", 10, "bold"),
            padx=20,
            pady=6
        )
        step1_btn.pack(side='right')
        
        # Step 2
        step2_frame = tk.Frame(instructions_frame, bg='white')
        step2_frame.pack(fill='x')
        
        tk.Label(
            step2_frame,
            text="2. Insert cuvette & press Enter",
            font=("Montserrat", 11),
            bg='white',
            fg=self.COLORS['dark']
        ).pack(side='left', padx=(0, 15))
        
        step2_btn = tk.Button(
            step2_frame,
            text="Enter",
            command=self.insert_cuvette,
            bg=self.COLORS['success'],
            fg="white",
            font=("Montserrat", 10, "bold"),
            padx=20,
            pady=6
        )
        step2_btn.pack(side='right')
        
        # Right panel - Results and Chart
        right_panel = tk.Frame(content, bg='white', relief=tk.RAISED, bd=2)
        right_panel.pack(side='right', fill='both', expand=True, padx=(10, 0))
        
        # Right panel header
        right_header = tk.Frame(right_panel, bg=self.COLORS['primary'], height=40)
        right_header.pack(fill='x')
        
        tk.Label(
            right_header,
            text="Analysis Results",
            font=("Montserrat", 14, "bold"),
            fg="white",
            bg=self.COLORS['primary']
        ).pack(side='left', padx=15)
        
        # Results table
        results_frame = tk.Frame(right_panel, bg='white', padx=20, pady=20)
        results_frame.pack(fill='both', expand=True)
        
        # Table header
        table_header = tk.Frame(results_frame, bg=self.COLORS['secondary'])
        table_header.pack(fill='x')
        
        tk.Label(
            table_header,
            text="ID",
            font=("Montserrat", 12, "bold"),
            fg="white",
            bg=self.COLORS['secondary'],
            width=15
        ).pack(side='left', padx=1)
        
        tk.Label(
            table_header,
            text="Result",
            font=("Montserrat", 12, "bold"),
            fg="white",
            bg=self.COLORS['secondary'],
            width=15
        ).pack(side='left', padx=1)
        
        tk.Label(
            table_header,
            text="Time",
            font=("Montserrat", 12, "bold"),
            fg="white",
            bg=self.COLORS['secondary'],
            width=15
        ).pack(side='left', padx=1)
        
        # Parasite count table
        parasite_data = [
            ("No. of Parasite", "", ""),
            ("> 2000", "", ""),
            ("> 200", "", "secs"),
            ("> 20", "", ""),
            ("< 5", "", "")
        ]
        
        for i, (category, result, time) in enumerate(parasite_data):
            row_frame = tk.Frame(results_frame, bg='white' if i % 2 == 0 else self.COLORS['light'])
            row_frame.pack(fill='x', pady=1)
            
            tk.Label(
                row_frame,
                text=category,
                font=("Montserrat", 11),
                bg=row_frame.cget('bg'),
                fg=self.COLORS['dark'],
                width=15
            ).pack(side='left', padx=1)
            
            # Result entry
            result_var = tk.StringVar(value=result)
            result_entry = tk.Entry(
                row_frame,
                textvariable=result_var,
                font=("Montserrat", 11),
                width=15,
                relief=tk.SOLID,
                bd=1
            )
            result_entry.pack(side='left', padx=1)
            
            # Time entry
            time_var = tk.StringVar(value=time)
            time_entry = tk.Entry(
                row_frame,
                textvariable=time_var,
                font=("Montserrat", 11),
                width=15,
                relief=tk.SOLID,
                bd=1
            )
            time_entry.pack(side='left', padx=1)
        
        # Chart frame
        chart_frame = tk.Frame(right_panel, bg='white', padx=20, pady=20)
        chart_frame.pack(fill='both', expand=True)
        
        # Chart title
        tk.Label(
            chart_frame,
            text="AD3 Count vs Time",
            font=("Montserrat", 13, "bold"),
            bg='white',
            fg=self.COLORS['dark']
        ).pack(anchor='w')
        
        # Create chart
        self.create_chart(chart_frame)
        
        # Current stock display
        stock_frame = tk.Frame(main_container, bg=self.COLORS['dark'], height=40)
        stock_frame.pack(side='bottom', fill='x')
        
        self.stock_var = tk.StringVar(value="Current stock: 123")
        stock_label = tk.Label(
            stock_frame,
            textvariable=self.stock_var,
            font=("Montserrat", 11, "bold"),
            fg="white",
            bg=self.COLORS['dark']
        )
        stock_label.pack(side='right', padx=30)
        
        # Action buttons
        action_frame = tk.Frame(main_container, bg=self.COLORS['light'], pady=20)
        action_frame.pack(side='bottom', fill='x')
        
        # Start analysis button
        start_btn = tk.Button(
            action_frame,
            text="▶ Start Analysis",
            command=self.start_analysis,
            bg=self.COLORS['success'],
            fg="white",
            font=("Montserrat", 12, "bold"),
            padx=30,
            pady=10,
            relief=tk.RAISED,
            bd=2
        )
        start_btn.pack(side='left', padx=(30, 10))
        
        # Clear button
        clear_btn = tk.Button(
            action_frame,
            text="🗑️ Clear All",
            command=self.clear_all,
            bg=self.COLORS['danger'],
            fg="white",
            font=("Montserrat", 12, "bold"),
            padx=30,
            pady=10,
            relief=tk.RAISED,
            bd=2
        )
        clear_btn.pack(side='left', padx=10)
        
        # Save results button
        save_btn = tk.Button(
            action_frame,
            text="💾 Save Results",
            command=self.save_results,
            bg=self.COLORS['secondary'],
            fg="white",
            font=("Montserrat", 12, "bold"),
            padx=30,
            pady=10,
            relief=tk.RAISED,
            bd=2
        )
        save_btn.pack(side='left', padx=10)
    
    def create_chart(self, parent):
        """Create the AD3 Count vs Time chart"""
        # Create figure
        self.fig = plt.Figure(figsize=(6, 3), dpi=80, facecolor='white')
        self.ax = self.fig.add_subplot(111)
        
        # Sample data for the chart
        time_points = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        ad3_counts = [2, 4, 5, 8, 12, 20, 30, 40, 50, 60, 65, 70]
        
        # Plot the data
        self.ax.plot(time_points, ad3_counts, marker='o', color='#3498DB', linewidth=2)
        self.ax.fill_between(time_points, ad3_counts, alpha=0.3, color='#3498DB')
        
        # Set labels and title
        self.ax.set_xlabel("Time in minutes", fontweight='bold')
        self.ax.set_ylabel("AD3 Count", fontweight='bold')
        self.ax.set_title("Parasite Count Over Time", fontweight='bold', pad=10)
        
        # Set grid
        self.ax.grid(True, alpha=0.3)
        
        # Set limits
        self.ax.set_xlim(0, 13)
        self.ax.set_ylim(0, 80)
        
        # Add value labels on some points
        for i, (x, y) in enumerate(zip(time_points, ad3_counts)):
            if i % 2 == 0:  # Label every other point
                self.ax.annotate(f'{y}', (x, y), textcoords="offset points",
                               xytext=(0,10), ha='center', fontsize=8)
        
        self.fig.tight_layout()
        
        # Embed in tkinter
        self.chart_canvas = FigureCanvasTkAgg(self.fig, parent)
        self.chart_canvas.get_tk_widget().pack(fill='both', expand=True)
    
    def generate_id(self):
        """Generate a sample ID"""
        if self.id_method.get() == "auto":
            import random
            sample_id = f"SMP-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000, 9999)}"
            self.id_var.set(sample_id)
            messagebox.showinfo("ID Generated", f"Generated Sample ID: {sample_id}")
        else:
            messagebox.showinfo("Barcode Mode", "Please scan barcode or enter ID manually")
    
    def remove_cuvette(self):
        """Handle remove cuvette action"""
        self.date_var.set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        messagebox.showinfo("Step 1", "Cuvette removal confirmed. Please insert new cuvette.")
    
    def insert_cuvette(self):
        """Handle insert cuvette action"""
        self.date_var.set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        messagebox.showinfo("Step 2", "Cuvette inserted. Ready for analysis.")
    
    def start_analysis(self):
        """Start the analysis process"""
        if not self.id_var.get():
            messagebox.showwarning("Missing ID", "Please enter or generate a Sample ID first.")
            return
        
        # Simulate analysis
        messagebox.showinfo("Analysis Started", 
                          f"Starting analysis for Sample ID: {self.id_var.get()}\n"
                          "Please wait...")
        
        # Simulate results after delay
        self.after(2000, self.simulate_results)
    
    def simulate_results(self):
        """Simulate analysis results"""
        import random
        
        # Generate random results
        results = {
            "> 2000": random.randint(0, 50),
            "> 200": random.randint(100, 500),
            "> 20": random.randint(50, 200),
            "< 5": random.randint(0, 20)
        }
        
        # Update chart with new data
        self.ax.clear()
        
        # Generate new time series data
        time_points = list(range(1, 13))
        new_counts = [random.randint(0, 70) for _ in range(12)]
        new_counts.sort()
        
        self.ax.plot(time_points, new_counts, marker='o', color='#3498DB', linewidth=2)
        self.ax.fill_between(time_points, new_counts, alpha=0.3, color='#3498DB')
        
        self.ax.set_xlabel("Time in minutes", fontweight='bold')
        self.ax.set_ylabel("AD3 Count", fontweight='bold')
        self.ax.set_title(f"Analysis Results - {self.id_var.get()}", fontweight='bold', pad=10)
        self.ax.grid(True, alpha=0.3)
        self.ax.set_xlim(0, 13)
        self.ax.set_ylim(0, 80)
        
        self.fig.tight_layout()
        self.chart_canvas.draw()
        
        # Update stock (simulate using one test)
        current_stock = int(self.stock_var.get().split(": ")[1])
        self.stock_var.set(f"Current stock: {current_stock - 1}")
        
        messagebox.showinfo("Analysis Complete", 
                          f"Analysis completed for Sample ID: {self.id_var.get()}\n"
                          f"Results: {results}")
    
    def save_results(self):
        """Save analysis results"""
        if not self.id_var.get():
            messagebox.showwarning("No Data", "No analysis results to save.")
            return
        
        # In a real application, you would save to database or file
        messagebox.showinfo("Results Saved", 
                          f"Results for Sample ID: {self.id_var.get()} have been saved.")
    
    def clear_all(self):
        """Clear all input fields"""
        self.id_var.set("")
        self.date_var.set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        
        # Reset chart to initial state
        self.ax.clear()
        time_points = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        ad3_counts = [2, 4, 5, 8, 12, 20, 30, 40, 50, 60, 65, 70]
        
        self.ax.plot(time_points, ad3_counts, marker='o', color='#3498DB', linewidth=2)
        self.ax.fill_between(time_points, ad3_counts, alpha=0.3, color='#3498DB')
        self.ax.set_xlabel("Time in minutes", fontweight='bold')
        self.ax.set_ylabel("AD3 Count", fontweight='bold')
        self.ax.set_title("Parasite Count Over Time", fontweight='bold', pad=10)
        self.ax.grid(True, alpha=0.3)
        self.ax.set_xlim(0, 13)
        self.ax.set_ylim(0, 80)
        
        self.fig.tight_layout()
        self.chart_canvas.draw()
        
        messagebox.showinfo("Cleared", "All fields have been cleared.")
    
    def go_back(self):
        """Go back to home menu"""
        # Clean up matplotlib figure
        plt.close(self.fig)
        
        # Destroy current frame
        self.destroy()
        
        # Call back to home
        if self.go_back_callback:
            self.go_back_callback()

# Demo runner
if __name__ == "__main__":
    def go_back():
        print("Going back to home...")
        root.destroy()
    
    root = tk.Tk()
    root.title("I.V.D - Read Sample")
    root.geometry("1200x800")
    
    app = ReadSamplePage(root, go_back)
    root.mainloop()