import tkinter as tk
from tkinter import font

def create_communication_page(root, go_back_callback=None):
    """
    Create and return an enhanced communication page frame.
    
    Args:
        root: The parent tkinter window/container
        go_back_callback: Optional callback function for back button
    
    Returns:
        tk.Frame: The communication page frame
    """
    
    # Main frame for the communication page
    frame = tk.Frame(root, bg="#F0F7FF")
    frame.pack_propagate(False)
    
    # Custom fonts
    title_font = font.Font(family="Segoe UI", size=24, weight="bold")
    subtitle_font = font.Font(family="Segoe UI", size=12)
    button_font = font.Font(family="Segoe UI", size=12, weight="bold")
    status_font = font.Font(family="Segoe UI", size=10)
    
    def create_gradient_header():
        """Create a gradient-like header"""
        header = tk.Frame(frame, bg="#2C3E50", height=100)
        header.pack(fill="x", padx=0, pady=0)
        
        # Left side - Logo and Title
        logo_frame = tk.Frame(header, bg="#2C3E50")
        logo_frame.pack(side="left", padx=30, pady=20)
        
        # Logo/Title
        tk.Label(logo_frame, text="IVD", font=("Arial", 28, "bold"), 
                bg="#2C3E50", fg="#5DE2E7").pack(anchor="w")
        tk.Label(logo_frame, text="Communication Center", 
                font=subtitle_font, bg="#2C3E50", fg="#BDC3C7").pack(anchor="w")
        
        # Right side - Status and Back button
        right_frame = tk.Frame(header, bg="#2C3E50")
        right_frame.pack(side="right", padx=30, pady=20)
        
        # Connection status
        status_frame = tk.Frame(right_frame, bg="#34495E", relief=tk.RIDGE, bd=1)
        status_frame.pack(side="left", padx=10)
        
        status_indicator = tk.Canvas(status_frame, width=12, height=12, 
                                    bg="#E74C3C", highlightthickness=0)
        status_indicator.pack(padx=8, pady=8)
        status_indicator.create_oval(2, 2, 10, 10, fill="#E74C3C", outline="")
        
        tk.Label(status_frame, text="Offline", bg="#34495E", fg="white",
                font=status_font).pack(padx=(0, 8), pady=8)
        
        # Back button
        if go_back_callback:
            back_btn = tk.Button(right_frame, text="← Dashboard", 
                                command=go_back_callback,
                                bg="#3498DB", fg="white",
                                font=button_font, bd=0,
                                padx=15, pady=8,
                                cursor="hand2",
                                relief=tk.FLAT)
            back_btn.pack(side="left")
        
        return header, status_indicator
    
    def create_rounded_button(parent, text, icon, bg_color, command=None, width=220, height=60):
        """Create a modern rounded button with icon"""
        btn_frame = tk.Frame(parent, bg="#F0F7FF")
        
        canvas = tk.Canvas(btn_frame, width=width, height=height, 
                          bg="#F0F7FF", highlightthickness=0)
        canvas.pack()
        
        # Helper function to lighten color
        def lighten_color(hex_color, factor=0.2):
            """Lighten a hex color"""
            rgb = tuple(int(hex_color[i:i+2], 16) for i in (1, 3, 5))
            light_rgb = tuple(min(255, int(c + (255 - c) * factor)) for c in rgb)
            return f'#{light_rgb[0]:02x}{light_rgb[1]:02x}{light_rgb[2]:02x}'
        
        # Create rounded rectangle function
        def create_rounded_rectangle(canvas, x1, y1, x2, y2, r, **kwargs):
            """Helper function to draw rounded rectangle on canvas"""
            canvas.create_arc(x1, y1, x1+2*r, y1+2*r, start=90, extent=90, **kwargs)
            canvas.create_arc(x2-2*r, y1, x2, y1+2*r, start=0, extent=90, **kwargs)
            canvas.create_arc(x1, y2-2*r, x1+2*r, y2, start=180, extent=90, **kwargs)
            canvas.create_arc(x2-2*r, y2-2*r, x2, y2, start=270, extent=90, **kwargs)
            canvas.create_rectangle(x1+r, y1, x2-r, y2, **kwargs)
            canvas.create_rectangle(x1, y1+r, x2, y2-r, **kwargs)
        
        # Draw button with shadow effect
        radius = 15
        create_rounded_rectangle(canvas, 3, 3, width-3, height-3, radius, 
                                 fill="#D5DBDB", outline="#D5DBDB")
        create_rounded_rectangle(canvas, 0, 0, width, height, radius, 
                                 fill=bg_color, outline=bg_color)
        
        # Add icon and text
        canvas.create_text(40, height//2, text=icon, 
                          font=("Arial", 18), fill="white", anchor="w")
        canvas.create_text(70, height//2, text=text, 
                          font=button_font, fill="white", anchor="w")
        
        # Add hover effect
        def on_enter(e):
            canvas.delete("all")
            light_color = lighten_color(bg_color, 0.2)
            create_rounded_rectangle(canvas, 3, 3, width-3, height-3, radius, 
                                     fill="#D5DBDB", outline="#D5DBDB")
            create_rounded_rectangle(canvas, 0, 0, width, height, radius, 
                                     fill=light_color, outline=light_color)
            canvas.create_text(40, height//2, text=icon, 
                              font=("Arial", 18), fill="white", anchor="w")
            canvas.create_text(70, height//2, text=text, 
                              font=button_font, fill="white", anchor="w")
            canvas.config(cursor="hand2")
        
        def on_leave(e):
            canvas.delete("all")
            create_rounded_rectangle(canvas, 3, 3, width-3, height-3, radius, 
                                     fill="#D5DBDB", outline="#D5DBDB")
            create_rounded_rectangle(canvas, 0, 0, width, height, radius, 
                                     fill=bg_color, outline=bg_color)
            canvas.create_text(40, height//2, text=icon, 
                              font=("Arial", 18), fill="white", anchor="w")
            canvas.create_text(70, height//2, text=text, 
                              font=button_font, fill="white", anchor="w")
            canvas.config(cursor="")
        
        if command:
            canvas.bind("<Button-1>", lambda e: command())
            canvas.bind("<Enter>", on_enter)
            canvas.bind("<Leave>", on_leave)
        
        return btn_frame
    
    def create_status_panel():
        """Create status panel at the bottom"""
        panel = tk.Frame(frame, bg="white", relief=tk.RIDGE, bd=1)
        panel.pack(side="bottom", fill="x", padx=20, pady=20)
        
        # Status title
        tk.Label(panel, text="System Status", font=button_font,
                bg="white", fg="#2C3E50").pack(anchor="w", padx=20, pady=(15, 5))
        
        # Status grid
        status_grid = tk.Frame(panel, bg="white")
        status_grid.pack(fill="x", padx=20, pady=10)
        
        status_items = [
            ("Motor Status", "Ready", "#2ECC71"),
            ("Connection", "Active", "#3498DB"),
            ("Memory", "85%", "#F39C12"),
            ("Last Update", "Just Now", "#9B59B6")
        ]
        
        for i, (label, value, color) in enumerate(status_items):
            item_frame = tk.Frame(status_grid, bg="white")
            item_frame.grid(row=0, column=i, padx=20)
            
            tk.Label(item_frame, text=label, font=status_font,
                    bg="white", fg="#7F8C8D").pack()
            tk.Label(item_frame, text=value, font=button_font,
                    bg="white", fg=color).pack()
        
        return panel
    
    # Create the UI components
    header, status_indicator = create_gradient_header()
    
    # Main content area
    content = tk.Frame(frame, bg="#F0F7FF")
    content.pack(fill="both", expand=True, padx=30, pady=30)
    
    # Title
    tk.Label(content, text="Communication Modules", 
            font=title_font, bg="#F0F7FF", fg="#2C3E50").pack(anchor="w", pady=(0, 20))
    
    # Button grid (2x2)
    grid_frame = tk.Frame(content, bg="#F0F7FF")
    grid_frame.pack(fill="both", expand=True)
    
    # Define modules
    modules = [
        {
            "icon": "🏠",
            "name": "Motor Home",
            "color": "#3498DB",
            "command": lambda: update_status("Motor Home activated")
        },
        {
            "icon": "⚙️",
            "name": "Motor Move",
            "color": "#9B59B6",
            "command": lambda: update_status("Motor Move initiated")
        },
        {
            "icon": "📈",
            "name": "Blank Read",
            "color": "#2ECC71",
            "command": lambda: update_status("Blank Read in progress")
        },
        {
            "icon": "💾",
            "name": "Memory Check",
            "color": "#E74C3C",
            "command": lambda: update_status("Memory Check completed")
        }
    ]
    
    # Function to update status
    def update_status(message):
        """Update status indicator and show message"""
        status_indicator.config(bg="#2ECC71")
        status_indicator.delete("all")
        status_indicator.create_oval(2, 2, 10, 10, fill="#2ECC71", outline="")
        
        # Update status label
        for widget in status_indicator.master.winfo_children():
            if isinstance(widget, tk.Label):
                widget.config(text="Online")
                break
        
        # Show notification (you could replace this with a proper notification system)
        print(f"Status: {message}")
    
    # Create buttons in grid
    for i, module in enumerate(modules):
        row = i // 2
        col = i % 2
        
        btn = create_rounded_button(
            grid_frame,
            text=module["name"],
            icon=module["icon"],
            bg_color=module["color"],
            command=module["command"],
            width=280,
            height=80
        )
        btn.grid(row=row, column=col, padx=20, pady=20, sticky="nsew")
        
        # Configure grid weights
        grid_frame.grid_rowconfigure(row, weight=1)
        grid_frame.grid_columnconfigure(col, weight=1)
    
    # Add some additional controls
    control_frame = tk.Frame(content, bg="#F0F7FF")
    control_frame.pack(fill="x", pady=20)
    
    # Quick actions
    tk.Label(control_frame, text="Quick Actions", font=button_font,
            bg="#F0F7FF", fg="#2C3E50").pack(anchor="w")
    
    action_frame = tk.Frame(control_frame, bg="#F0F7FF")
    action_frame.pack(fill="x", pady=10)
    
    actions = [
        ("⟳", "Refresh All", "#F39C12"),
        ("⏸️", "Pause Motors", "#E74C3C"),
        ("▶️", "Resume All", "#2ECC71"),
        ("📋", "Logs", "#3498DB")
    ]
    
    for icon, text, color in actions:
        action_btn = tk.Button(action_frame, text=f"{icon} {text}",
                              bg=color, fg="white",
                              font=status_font, bd=0,
                              padx=15, pady=5,
                              cursor="hand2",
                              relief=tk.FLAT)
        action_btn.pack(side="left", padx=5)
    
    # Create status panel
    status_panel = create_status_panel()
    
    return frame

# For standalone testing
if __name__ == "__main__":
    root = tk.Tk()
    root.title("IVD Communication Center")
    root.geometry("1000x700")
    root.configure(bg="#2C3E50")
    
    def go_back():
        print("Going back to dashboard...")
        root.quit()
    
    # Create the communication page
    page = create_communication_page(root, go_back_callback=go_back)
    page.pack(fill="both", expand=True)
    
    root.mainloop()