import tkinter as tk
from tkinter import ttk
from tkinter import font

def create_reagent_page(root, go_back_callback=None):
    """
    Create and return a reagent management page frame.
    
    Args:
        root: The parent tkinter window/container
        go_back_callback: Optional callback function for back button
    
    Returns:
        tk.Frame: The reagent management page frame
    """
    
    # Main frame
    frame = tk.Frame(root, bg="#F5F7FA")
    frame.pack_propagate(False)
    
    # Custom fonts
    title_font = font.Font(family="Segoe UI", size=28, weight="bold")
    header_font = font.Font(family="Segoe UI", size=14, weight="bold")
    label_font = font.Font(family="Segoe UI", size=11)
    button_font = font.Font(family="Segoe UI", size=12, weight="bold")
    stat_font = font.Font(family="Segoe UI", size=22, weight="bold")
    
    def lighten_color(hex_color, percent):
        """Lighten a hex color by given percentage"""
        hex_color = hex_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        light_rgb = tuple(min(255, int(c + (255 - c) * percent/100)) for c in rgb)
        return f'#{light_rgb[0]:02x}{light_rgb[1]:02x}{light_rgb[2]:02x}'
    
    def rounded_button(parent, text, x, y, w, h, r, bg, fg="white",
                       font=button_font, command=None, hover_color=None):
        """Enhanced rounded button with hover effects"""
        if hover_color is None:
            hover_color = lighten_color(bg, 20)
        
        c = tk.Canvas(parent, width=w, height=h,
                      bg=parent.cget("bg"), highlightthickness=0)
        c.place(x=x, y=y)
        
        def draw_button(canvas, color):
            canvas.delete("all")
            canvas.create_arc(0, 0, r*2, r*2, start=90, extent=90, fill=color, outline=color)
            canvas.create_arc(w-r*2, 0, w, r*2, start=0, extent=90, fill=color, outline=color)
            canvas.create_arc(0, h-r*2, r*2, h, start=180, extent=90, fill=color, outline=color)
            canvas.create_arc(w-r*2, h-r*2, w, h, start=270, extent=90, fill=color, outline=color)
            
            canvas.create_rectangle(r, 0, w-r, h, fill=color, outline=color)
            canvas.create_rectangle(0, r, w, h-r, fill=color, outline=color)
            
            canvas.create_text(w//2, h//2, text=text, fill=fg, font=font)
        
        def on_enter(e):
            c.config(cursor="hand2")
            draw_button(c, hover_color)
        
        def on_leave(e):
            c.config(cursor="")
            draw_button(c, bg)
        
        draw_button(c, bg)
        
        if command:
            c.bind("<Button-1>", lambda e: command())
            c.bind("<Enter>", on_enter)
            c.bind("<Leave>", on_leave)
        
        return c
    
    def create_stat_card(parent, title, value, color, x, y):
        """Create a modern statistic card"""
        card = tk.Frame(parent, bg="white", relief=tk.RAISED, bd=1)
        card.place(x=x, y=y, width=180, height=100)
        
        # Title
        tk.Label(card, text=title, bg="white", fg="#666666",
                 font=label_font).place(x=20, y=20)
        
        # Value
        tk.Label(card, text=value, bg="white", fg=color,
                 font=stat_font).place(x=20, y=45)
        
        # Color accent
        accent = tk.Frame(card, bg=color, width=5, height=100)
        accent.place(x=0, y=0)
        
        return card
    
    def create_input_field(parent, label, x, y, width=200, entry_type="entry"):
        """Create labeled input field"""
        # Label
        tk.Label(parent, text=label, bg=parent.cget("bg"), fg="#444444",
                 font=label_font).place(x=x, y=y)
        
        # Input field
        if entry_type == "entry":
            entry = tk.Entry(parent, width=20, font=("Segoe UI", 11),
                            relief=tk.FLAT, bd=2, bg="white")
            entry.place(x=x + 100, y=y-3)
            
            # Add underline effect
            underline = tk.Frame(parent, height=2, bg="#5DE2E7")
            underline.place(x=x + 100, y=y+22, width=width)
            
            def on_focus_in(e):
                underline.config(bg="#3498DB")
            
            def on_focus_out(e):
                underline.config(bg="#5DE2E7")
            
            entry.bind("<FocusIn>", on_focus_in)
            entry.bind("<FocusOut>", on_focus_out)
            
            return entry
        else:  # combobox
            combo = ttk.Combobox(parent, values=["1", "2", "3", "4", "5"], 
                               width=18, state="readonly", font=("Segoe UI", 11))
            combo.place(x=x + 100, y=y-3)
            combo.current(0)
            
            # Style combobox
            style = ttk.Style()
            style.theme_use('clam')
            style.configure("TCombobox", fieldbackground="white", background="white")
            
            return combo
    
    def create_header():
        """Create the header section"""
        header = tk.Frame(frame, bg="#2C3E50", height=80)
        header.pack(fill="x")
        
        # Left side - Logo and Title
        left_header = tk.Frame(header, bg="#2C3E50")
        left_header.pack(side="left", padx=30, pady=20)
        
        tk.Label(left_header, text="I . V . D", bg="#2C3E50", fg="#5DE2E7",
                 font=title_font).pack(anchor="w")
        
        tk.Label(left_header, text="Reagent Management System", bg="#2C3E50", fg="#BDC3C7",
                 font=("Segoe UI", 10)).pack(anchor="w")
        
        # Right side - User info and back button
        right_header = tk.Frame(header, bg="#2C3E50")
        right_header.pack(side="right", padx=30, pady=20)
        
        # Back button
        if go_back_callback:
            back_btn = tk.Button(right_header, text="← Dashboard", 
                                command=go_back_callback,
                                bg="#3498DB", fg="white",
                                font=button_font, bd=0,
                                padx=15, pady=8,
                                cursor="hand2",
                                relief=tk.FLAT)
            back_btn.pack(side="left", padx=(10, 0))
        
        tk.Label(right_header, text="⚙️ System Admin", bg="#2C3E50", fg="white",
                 font=("Segoe UI", 11)).pack(side="left")
        
        return header
    
    def create_statistics_panel():
        """Create the statistics panel"""
        panel = tk.Frame(frame, bg="#F5F7FA", width=400)
        panel.pack(side="left", fill="y", padx=(20, 20), pady=20)
        
        # Statistics cards
        create_stat_card(panel, "Remaining Tests", "100", "#F39C12", 0, 0)
        create_stat_card(panel, "Active Reagents", "5", "#2ECC71", 200, 0)
        # create_stat_card(panel, "Expires In", "7 days", "#E74C3C", 0, 120)
        create_stat_card(panel, "Last Updated", "Today", "#3498DB", 200, 120)
        
        # Add some informational text
        info_frame = tk.Frame(panel, bg="#F5F7FA")
        info_frame.place(x=0, y=240, width=380, height=100)
        
        tk.Label(info_frame, text="📊 Usage Statistics", bg="#F5F7FA", fg="#2C3E50",
                 font=header_font).pack(anchor="w", pady=(0, 10))
        
        stats = [
            ("Daily Usage:", "12 tests/day"),
            ("Monthly Total:", "360 tests"),
            ("Efficiency:", "98.5%")
        ]
        
        for i, (label, value) in enumerate(stats):
            stat_frame = tk.Frame(info_frame, bg="#F5F7FA")
            stat_frame.place(x=0, y=40 + i*25)
            
            tk.Label(stat_frame, text=label, bg="#F5F7FA", fg="#666666",
                     font=label_font).pack(side="left")
            tk.Label(stat_frame, text=value, bg="#F5F7FA", fg="#2C3E50",
                     font=label_font).pack(side="left", padx=(10, 0))
        
        return panel
    
    def create_control_panel():
        """Create the control panel with input fields and buttons"""
        panel = tk.Frame(frame, bg="white", relief=tk.RAISED, bd=1)
        panel.pack(side="left", fill="both", expand=True, padx=(0, 20), pady=20)
        
        # Panel header
        panel_header = tk.Frame(panel, bg="#5DE2E7", height=60)
        panel_header.pack(fill="x")
        
        tk.Label(panel_header, text="Reagent Control Panel", bg="#5DE2E7", fg="white",
                 font=header_font).pack(side="left", padx=20)
        
        panel_content = tk.Frame(panel, bg="white")
        panel_content.pack(fill="both", expand=True, padx=40, pady=40)
        
        # Purchase Button (Large)
        purchase_btn = rounded_button(
            panel_content,
            "🛒 Purchase Reagent",
            x=50, y=30,
            w=300, h=60,
            r=20,
            bg="#3498DB",
            fg="white",
            font=font.Font(family="Segoe UI", size=13, weight="bold"),
            hover_color="#2980B9",
            command=lambda: print("Opening reagent purchase...")
        )
        
        # OTP Section
        otp_section = tk.Frame(panel_content, bg="white")
        otp_section.place(x=50, y=120, width=400, height=80)
        
        tk.Label(otp_section, text="🔒 Enter OTP for Verification", bg="white", fg="#2C3E50",
                 font=header_font).place(x=0, y=0)
        
        otp_entry = create_input_field(otp_section, "OTP Code:", 0, 40)
        
        verify_btn = rounded_button(
            otp_section,
            "Verify",
            x=280, y=35,
            w=100, h=40,
            r=12,
            bg="#2ECC71",
            fg="white",
            hover_color="#27AE60",
            command=lambda: verify_otp(otp_entry.get())
        )
        
        # Box Selection
        box_section = tk.Frame(panel_content, bg="white")
        box_section.place(x=50, y=220, width=400, height=80)
        
        tk.Label(box_section, text="📦 Reagent Configuration", bg="white", fg="#2C3E50",
                 font=header_font).place(x=0, y=0)
        
        box_combo = create_input_field(box_section, "No. of Boxes:", 0, 40, entry_type="combobox")
        
        # Load Reagent Button (Primary Action)
        load_btn = rounded_button(
            panel_content,
            "⚡ Load Reagent",
            x=50, y=320,
            w=300, h=70,
            r=25,
            bg="#E74C3C",
            fg="white",
            font=font.Font(family="Segoe UI", size=14, weight="bold"),
            hover_color="#C0392B",
            command=lambda: load_reagent(box_combo.get())
        )
        
        return panel, otp_entry, box_combo
    
    def create_status_bar():
        """Create status bar at bottom"""
        status_bar = tk.Frame(frame, bg="#34495E", height=30)
        status_bar.pack(side="bottom", fill="x")
        
        status_label = tk.Label(status_bar, text="✅ System Ready | Last Update: 10:30 AM", 
                               bg="#34495E", fg="#BDC3C7", font=("Segoe UI", 9))
        status_label.pack(side="left", padx=20)
        
        return status_bar, status_label
    
    def create_back_button():
        """Create floating back button"""
        back_btn = tk.Canvas(frame, width=60, height=60, bg="#F5F7FA", highlightthickness=0)
        back_btn.place(x=920, y=520)
        
        # Draw circular back button with shadow
        back_btn.create_oval(5, 5, 55, 55, fill="#4DA6FF", outline="#4DA6FF")
        back_btn.create_oval(3, 3, 53, 53, fill="#3498DB", outline="#3498DB")
        back_btn.create_text(30, 30, text="◀", fill="white", font=("Arial", 20, "bold"))
        
        # Add hover effect to back button
        def on_back_enter(e):
            back_btn.config(cursor="hand2")
            back_btn.delete("all")
            back_btn.create_oval(5, 5, 55, 55, fill="#3A8CD6", outline="#3A8CD6")
            back_btn.create_oval(3, 3, 53, 53, fill="#2980B9", outline="#2980B9")
            back_btn.create_text(30, 30, text="◀", fill="white", font=("Arial", 20, "bold"))
        
        def on_back_leave(e):
            back_btn.config(cursor="")
            back_btn.delete("all")
            back_btn.create_oval(5, 5, 55, 55, fill="#4DA6FF", outline="#4DA2E7")
            back_btn.create_oval(3, 3, 53, 53, fill="#3498DB", outline="#3498DB")
            back_btn.create_text(30, 30, text="◀", fill="white", font=("Arial", 20, "bold"))
        
        if go_back_callback:
            back_btn.bind("<Button-1>", lambda e: go_back_callback())
            back_btn.bind("<Enter>", on_back_enter)
            back_btn.bind("<Leave>", on_back_leave)
        
        return back_btn
    
    # Business logic functions
    def verify_otp(otp_code):
        """Verify OTP code"""
        if otp_code and len(otp_code) == 6:
            print(f"OTP Verified: {otp_code}")
            # In real application, you would:
            # 1. Validate OTP with server
            # 2. Update UI to show success
            # 3. Enable load reagent button
        else:
            print("Invalid OTP")
    
    def load_reagent(box_count):
        """Load reagent with specified box count"""
        print(f"Loading {box_count} box(es) of reagent...")
        # In real application, you would:
        # 1. Send command to hardware
        # 2. Show loading animation
        # 3. Update status when complete
    
    # Build the UI
    create_header()
    create_statistics_panel()
    control_panel, otp_entry, box_combo = create_control_panel()
    status_bar, status_label = create_status_bar()
    back_button = create_back_button()
    
    return frame

# For standalone testing
if __name__ == "__main__":
    root = tk.Tk()
    root.title("IVD - Reagent Management")
    root.geometry("1000x600")
    root.configure(bg="#2C3E50")
    
    def go_back():
        print("Going back to dashboard...")
        root.quit()
    
    # Create the reagent page
    page = create_reagent_page(root, go_back_callback=go_back)
    page.pack(fill="both", expand=True)
    
    root.mainloop()